import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2024-04-10",
});

// Crea l'addebito sul mittente. I fondi restano sul conto piattaforma
// finché il regalo non viene riscosso (vedi redeem.routes.ts).
export async function creaPaymentIntent(params: {
  importoCent: number;
  stripeCustomerId?: string;
  giftId: string;
}) {
  return stripe.paymentIntents.create({
    amount: params.importoCent,
    currency: "eur",
    customer: params.stripeCustomerId,
    metadata: { giftId: params.giftId },
    automatic_payment_methods: { enabled: true },
  });
}

// Trasferisce i fondi al conto Stripe Connect del locale, al netto
// della commissione. Va chiamata dal job di payout periodico, non
// alla singola riscossione, per aggregare più regali in un bonifico.
export async function creaTransferVersoLocale(params: {
  importoCent: number;
  stripeAccountId: string;
  payoutId: string;
}) {
  return stripe.transfers.create({
    amount: params.importoCent,
    currency: "eur",
    destination: params.stripeAccountId,
    metadata: { payoutId: params.payoutId },
  });
}

export { stripe };
