import jwt from "jsonwebtoken";

const SEGRETO = process.env.JWT_SECRET || "";
if (!SEGRETO) {
  // Meglio fallire subito all'avvio che emettere token con un
  // segreto vuoto/prevedibile in un ambiente mal configurato.
  throw new Error("JWT_SECRET non impostato");
}

export type Ruolo = "utente" | "locale" | "admin";

export type PayloadToken = {
  sub: string; // id dell'utente, del locale o dell'admin, a seconda del ruolo
  ruolo: Ruolo;
};

const DURATA_TOKEN: Record<Ruolo, string> = {
  utente: "30d", // l'app mobile resta collegata a lungo, come qualunque consumer app
  locale: "12h", // sessione del turno al banco
  admin: "8h",
};

export function firmaToken(payload: PayloadToken): string {
  return jwt.sign(payload, SEGRETO, { expiresIn: DURATA_TOKEN[payload.ruolo] });
}

export function verificaToken(token: string): PayloadToken {
  return jwt.verify(token, SEGRETO) as PayloadToken;
}
