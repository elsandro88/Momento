import "dotenv/config";
import express from "express";
import cors from "cors";
import { localiRouter } from "./routes/locali.routes";
import { giftsRouter } from "./routes/gifts.routes";
import { redeemRouter } from "./routes/redeem.routes";
import { paymentsRouter } from "./routes/payments.routes";
import { adminRouter } from "./routes/admin.routes";
import { authRouter } from "./routes/auth.routes";

const app = express();

// Il webhook Stripe va montato PRIMA di express.json(), perché ha
// bisogno del body raw per verificare la firma (vedi payments.routes.ts).
app.use("/webhooks", paymentsRouter);

app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/locali", localiRouter);
app.use("/gifts", giftsRouter);
app.use("/redeem", redeemRouter);
app.use("/auth", authRouter);
app.use("/admin", adminRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend in ascolto su http://localhost:${PORT}`);
});
