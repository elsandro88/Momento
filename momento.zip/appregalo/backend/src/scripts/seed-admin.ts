import "dotenv/config";
import bcrypt from "bcryptjs";
import { prisma } from "../db";

// Uso: EMAIL=... PASSWORD=... NOME=... npm run seed:admin
async function main() {
  const email = process.env.EMAIL;
  const password = process.env.PASSWORD;
  const nome = process.env.NOME || "Admin";

  if (!email || !password) {
    console.error("Imposta EMAIL e PASSWORD come variabili d'ambiente.");
    process.exit(1);
  }
  if (password.length < 8) {
    console.error("La password deve avere almeno 8 caratteri.");
    process.exit(1);
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const admin = await prisma.admin.upsert({
    where: { email },
    update: { passwordHash, nome },
    create: { email, passwordHash, nome },
  });

  console.log(`Admin pronto: ${admin.email}`);
}

main().finally(() => prisma.$disconnect());
