import { PrismaClient } from "@prisma/client";

// Istanza unica del client Prisma condivisa da tutte le route.
export const prisma = new PrismaClient();
