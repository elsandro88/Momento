import { Request, Response, NextFunction } from "express";
import { verificaToken, Ruolo } from "../services/token.service";

declare global {
  namespace Express {
    interface Request {
      auth?: { id: string; ruolo: Ruolo };
    }
  }
}

// richiedeRuolo(["locale"]) protegge una route lasciando passare solo
// token validi con quel ruolo; richiedeRuolo() (senza argomenti)
// richiede solo che il token sia valido, qualunque sia il ruolo.
export function richiedeRuolo(ruoliAmmessi?: Ruolo[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const header = req.headers.authorization;
    if (!header?.startsWith("Bearer ")) {
      return res.status(401).json({ errore: "Token mancante" });
    }

    try {
      const payload = verificaToken(header.slice("Bearer ".length));
      if (ruoliAmmessi && !ruoliAmmessi.includes(payload.ruolo)) {
        return res.status(403).json({ errore: "Ruolo non autorizzato" });
      }
      req.auth = { id: payload.sub, ruolo: payload.ruolo };
      next();
    } catch {
      return res.status(401).json({ errore: "Token non valido o scaduto" });
    }
  };
}
