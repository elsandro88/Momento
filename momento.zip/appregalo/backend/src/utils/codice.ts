import { customAlphabet } from "nanoid";

// Alfabeto senza caratteri ambigui (niente 0/O, 1/I) per farlo leggere
// facilmente a voce al banco del locale.
const alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const generaCodice = customAlphabet(alfabeto, 6);

export function nuovoCodiceRegalo(): string {
  return generaCodice();
}
