// La commissione di servizio è a carico del mittente, non del locale
// — il locale riceve sempre l'intero importoTotale. È una costante di
// piattaforma (non per locale) perché il prezzo che il mittente vede
// deve essere prevedibile indipendentemente da dove sta regalando.
const PERCENTUALE_SERVIZIO = Number(process.env.SERVIZIO_PERCENTUALE ?? 5); // %
const FISSA_SERVIZIO = Number(process.env.SERVIZIO_FISSA ?? 0.3); // €

export function calcolaFeeServizio(importoTotale: number): number {
  const fee = importoTotale * (PERCENTUALE_SERVIZIO / 100) + FISSA_SERVIZIO;
  return Math.round(fee * 100) / 100;
}
