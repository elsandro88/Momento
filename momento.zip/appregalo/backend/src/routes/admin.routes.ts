import { Router } from "express";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { creaTransferVersoLocale } from "../services/stripe.service";
import { richiedeRuolo } from "../middleware/auth.middleware";

export const adminRouter = Router();
adminRouter.use(richiedeRuolo(["admin"]));

// GET /admin/locali — tutti i locali, qualunque stato (a differenza di
// GET /locali che è quello pubblico e mostra solo gli attivi).
adminRouter.get("/locali", async (_req, res) => {
  const locali = await prisma.locale.findMany({ orderBy: { createdAt: "desc" } });
  res.json(locali);
});

const nuovoLocaleSchema = z.object({
  nome: z.string().min(1),
  citta: z.string().min(1),
  categoria: z.string().min(1),
});
// POST /admin/locali — onboarding manuale di un nuovo locale, entra
// in stato "in_attesa" finché non viene approvato. Il PIN generato
// qui va comunicato al locale a voce/di persona: non è recuperabile
// in seguito, solo rigenerabile.
adminRouter.post("/locali", async (req, res) => {
  const parsed = nuovoLocaleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });

  const pin = String(Math.floor(1000 + Math.random() * 9000));
  const pinHash = await bcrypt.hash(pin, 10);

  const locale = await prisma.locale.create({ data: { ...parsed.data, pinHash } });
  res.status(201).json({ locale, pin });
});

// POST /admin/locali/:id/rigenera-pin — da usare se il locale perde
// il PIN o sospetta che sia stato condiviso con troppe persone.
adminRouter.post("/locali/:id/rigenera-pin", async (req, res) => {
  const pin = String(Math.floor(1000 + Math.random() * 9000));
  const pinHash = await bcrypt.hash(pin, 10);

  await prisma.locale.update({ where: { id: req.params.id }, data: { pinHash } });
  res.json({ pin });
});

const aggiornaLocaleSchema = z.object({
  stato: z.enum(["in_attesa", "attivo", "sospeso"]).optional(),
  stripeAccountId: z.string().optional(),
});

// PATCH /admin/locali/:id — approvazione, sospensione, aggiornamento
// commissione o collegamento del conto Stripe Connect.
adminRouter.patch("/locali/:id", async (req, res) => {
  const parsed = aggiornaLocaleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });

  const locale = await prisma.locale.update({
    where: { id: req.params.id },
    data: parsed.data,
  });
  res.json(locale);
});

// GET /admin/payouts/pending — regali riscossi non ancora inclusi in
// nessun payout, raggruppati per locale. Il locale riceve l'intero
// importoTotale: nessuna commissione trattenuta, la piattaforma si
// ripaga con la fee di servizio già incassata dal mittente al momento
// dell'acquisto.
adminRouter.get("/payouts/pending", async (_req, res) => {
  const regaliNonPagati = await prisma.gift.findMany({
    where: { stato: "riscosso", payoutGifts: { none: {} } },
    include: { locale: true },
  });

  const perLocale = new Map<string, { locale: typeof regaliNonPagati[0]["locale"]; totale: number; numeroRegali: number }>();

  for (const regalo of regaliNonPagati) {
    const voce = perLocale.get(regalo.localeId) ?? { locale: regalo.locale, totale: 0, numeroRegali: 0 };
    voce.totale += Number(regalo.importoTotale);
    voce.numeroRegali += 1;
    perLocale.set(regalo.localeId, voce);
  }

  res.json(Array.from(perLocale.values()));
});

// POST /admin/payouts/process — crea un Payout per ogni locale con
// regali in sospeso, collega le righe (payout_gifts) per la
// riconciliazione, e avvia il trasferimento Stripe Connect.
// In produzione andrebbe schedulato (es. cron settimanale), qui è
// esposto come azione manuale per l'admin.
adminRouter.post("/payouts/process", async (_req, res) => {
  const regaliNonPagati = await prisma.gift.findMany({
    where: { stato: "riscosso", payoutGifts: { none: {} } },
    include: { locale: true },
  });

  const perLocale = new Map<string, typeof regaliNonPagati>();
  for (const regalo of regaliNonPagati) {
    const lista = perLocale.get(regalo.localeId) ?? [];
    lista.push(regalo);
    perLocale.set(regalo.localeId, lista);
  }

  const payoutCreati = [];
  const oggi = new Date();
  const settimanaFa = new Date(oggi);
  settimanaFa.setDate(settimanaFa.getDate() - 7);

  for (const [localeId, regali] of perLocale) {
    const locale = regali[0].locale;
    const importoTotale = regali.reduce((somma, r) => somma + Number(r.importoTotale), 0);

    const payout = await prisma.payout.create({
      data: {
        localeId,
        importoTotale,
        periodoInizio: settimanaFa,
        periodoFine: oggi,
        payoutGifts: { create: regali.map((r) => ({ giftId: r.id })) },
      },
    });

    if (locale.stripeAccountId) {
      const transfer = await creaTransferVersoLocale({
        importoCent: Math.round(importoTotale * 100),
        stripeAccountId: locale.stripeAccountId,
        payoutId: payout.id,
      });
      await prisma.payout.update({
        where: { id: payout.id },
        data: { stripeTransferId: transfer.id, stato: "inviato" },
      });
    }

    payoutCreati.push(payout);
  }

  res.json({ payoutCreati: payoutCreati.length });
});
