import { Router } from "express";
import { z } from "zod";
import { prisma } from "../db";
import { richiedeRuolo } from "../middleware/auth.middleware";

export const redeemRouter = Router();

const redeemSchema = z.object({
  codice: z.string().length(6),
});

// POST /redeem — richiede un token "locale" valido: il locale che
// riscuote è quello autenticato (req.auth.id), non un campo passato
// dal client. Impedisce a un locale di validare codici altrui anche
// se conoscesse per sbaglio il loro id.
redeemRouter.post("/", richiedeRuolo(["locale"]), async (req, res) => {
  const parsed = redeemSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ errore: parsed.error.flatten() });
  }
  const { codice } = parsed.data;
  const localeId = req.auth!.id;

  const gift = await prisma.gift.findUnique({
    where: { codice },
    include: { items: true },
  });

  if (!gift || gift.localeId !== localeId) {
    return res.status(404).json({ errore: "Codice non valido per questo locale" });
  }
  if (gift.stato === "riscosso") {
    return res.status(409).json({ errore: "Codice già utilizzato" });
  }
  if (gift.stato === "scaduto" || gift.scadenza < new Date()) {
    return res.status(410).json({ errore: "Codice scaduto" });
  }

  const aggiornato = await prisma.gift.update({
    where: { id: gift.id },
    data: { stato: "riscosso", redeemedAt: new Date() },
    include: { items: true },
  });

  // Nota: il trasferimento verso il locale avviene nel job di payout
  // periodico, non qui — questa route conferma solo la riscossione.
  res.json({ esito: "ok", gift: aggiornato });
});
