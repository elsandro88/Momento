import { Router } from "express";
import { z } from "zod";
import { prisma } from "../db";
import { nuovoCodiceRegalo } from "../utils/codice";
import { creaPaymentIntent } from "../services/stripe.service";
import { calcolaFeeServizio } from "../utils/commissione";
import { richiedeRuolo } from "../middleware/auth.middleware";

export const giftsRouter = Router();

const GIORNI_VALIDITA = 60;

const itemSchema = z.object({
  voceMenuId: z.string().uuid().optional(),
  nomeProdotto: z.string().min(1),
  quantita: z.number().int().positive().max(20),
  prezzoUnitario: z.number().nonnegative(),
});

const creaGiftSchema = z.object({
  destinatarioTelefono: z.string().min(6),
  localeId: z.string().uuid(),
  messaggio: z.string().max(280).optional(),
  items: z.array(itemSchema).min(1).max(20),
});

// POST /gifts — richiede un utente autenticato: il mittente è chi ha
// fatto login (req.auth.id), non un campo passato nel body, così
// nessuno può creare regali a nome di qualcun altro.
giftsRouter.post("/", richiedeRuolo(["utente"]), async (req, res) => {
  const parsed = creaGiftSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ errore: parsed.error.flatten() });
  }
  const dati = parsed.data;
  const mittenteId = req.auth!.id;

  const mittente = await prisma.user.findUnique({ where: { id: mittenteId } });
  if (!mittente) return res.status(404).json({ errore: "Mittente non trovato" });

  const importoTotale = dati.items.reduce(
    (somma, item) => somma + item.quantita * item.prezzoUnitario,
    0
  );
  const feeServizio = calcolaFeeServizio(importoTotale);
  const importoAddebitato = importoTotale + feeServizio;

  const scadenza = new Date();
  scadenza.setDate(scadenza.getDate() + GIORNI_VALIDITA);

  const gift = await prisma.gift.create({
    data: {
      mittenteId,
      destinatarioTelefono: dati.destinatarioTelefono,
      localeId: dati.localeId,
      messaggio: dati.messaggio,
      codice: nuovoCodiceRegalo(),
      scadenza,
      importoTotale,
      feeServizio,
      items: {
        create: dati.items.map((item) => ({
          voceMenuId: item.voceMenuId,
          nomeProdotto: item.nomeProdotto,
          quantita: item.quantita,
          prezzoUnitario: item.prezzoUnitario,
        })),
      },
    },
    include: { items: true },
  });

  const paymentIntent = await creaPaymentIntent({
    importoCent: Math.round(importoAddebitato * 100),
    stripeCustomerId: mittente.stripeCustomerId ?? undefined,
    giftId: gift.id,
  });

  await prisma.payment.create({
    data: {
      giftId: gift.id,
      stripePaymentIntentId: paymentIntent.id,
      importo: importoAddebitato,
      stato: paymentIntent.status,
    },
  });

  res.status(201).json({
    gift,
    clientSecret: paymentIntent.client_secret,
  });
});

// GET /gifts/:id — volutamente SENZA autenticazione: il destinatario
// apre questo link da un SMS prima ancora di avere un account.
// La sicurezza sta nell'id (uuid non indovinabile), non in un login —
// stesso principio di un link "magico" di reset password.
giftsRouter.get("/:id", async (req, res) => {
  const gift = await prisma.gift.findUnique({
    where: { id: req.params.id },
    include: { locale: true, items: true },
  });

  if (!gift) return res.status(404).json({ errore: "Regalo non trovato" });
  res.json(gift);
});
