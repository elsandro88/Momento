import { Router } from "express";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { firmaToken } from "../services/token.service";
import { nuovoCodiceRegalo } from "../utils/codice";

export const authRouter = Router();

const MINUTI_VALIDITA_OTP = 5;

// --- Mittente: accesso via OTP SMS, niente password da ricordare ---

authRouter.post("/utente/richiedi-otp", async (req, res) => {
  const schema = z.object({ telefono: z.string().min(6) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });

  const codice = nuovoCodiceRegalo().slice(0, 4); // 4 cifre bastano per un OTP, più veloce da digitare
  const scadenza = new Date(Date.now() + MINUTI_VALIDITA_OTP * 60 * 1000);

  await prisma.codiceAccesso.create({
    data: { telefono: parsed.data.telefono, codice, scadenza },
  });

  // TODO: qui va agganciato il vero invio SMS (es. Twilio). In
  // sviluppo il codice va semplicemente in console.
  console.log(`OTP per ${parsed.data.telefono}: ${codice}`);

  res.json({ inviato: true });
});

authRouter.post("/utente/verifica-otp", async (req, res) => {
  const schema = z.object({ telefono: z.string().min(6), codice: z.string().min(4) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });
  const { telefono, codice } = parsed.data;

  const richiesta = await prisma.codiceAccesso.findFirst({
    where: { telefono, codice, utilizzato: false, scadenza: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
  });

  if (!richiesta) {
    return res.status(401).json({ errore: "Codice non valido o scaduto" });
  }

  await prisma.codiceAccesso.update({ where: { id: richiesta.id }, data: { utilizzato: true } });

  // Primo accesso con questo numero: creiamo l'utente al volo, senza
  // form di registrazione separato.
  const utente = await prisma.user.upsert({
    where: { telefono },
    update: {},
    create: { telefono, nome: "", email: `${telefono}@segnaposto.appregalo` },
  });

  const token = firmaToken({ sub: utente.id, ruolo: "utente" });
  res.json({ token, utente });
});

// --- Staff del locale: accesso con ID locale + PIN ---

authRouter.post("/locale/accedi", async (req, res) => {
  const schema = z.object({ localeId: z.string().uuid(), pin: z.string().min(4) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });

  const locale = await prisma.locale.findUnique({ where: { id: parsed.data.localeId } });
  if (!locale) return res.status(401).json({ errore: "Credenziali non valide" });

  const pinValido = await bcrypt.compare(parsed.data.pin, locale.pinHash);
  if (!pinValido) return res.status(401).json({ errore: "Credenziali non valide" });

  const token = firmaToken({ sub: locale.id, ruolo: "locale" });
  res.json({ token, locale: { id: locale.id, nome: locale.nome } });
});

// --- Admin: email + password, nessuna auto-registrazione via API ---
// (il primo admin si crea con `npm run seed:admin`, vedi README)

authRouter.post("/admin/accedi", async (req, res) => {
  const schema = z.object({ email: z.string().email(), password: z.string().min(8) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ errore: parsed.error.flatten() });

  const admin = await prisma.admin.findUnique({ where: { email: parsed.data.email } });
  if (!admin) return res.status(401).json({ errore: "Credenziali non valide" });

  const passwordValida = await bcrypt.compare(parsed.data.password, admin.passwordHash);
  if (!passwordValida) return res.status(401).json({ errore: "Credenziali non valide" });

  const token = firmaToken({ sub: admin.id, ruolo: "admin" });
  res.json({ token, admin: { id: admin.id, nome: admin.nome, email: admin.email } });
});
