import { Router, raw } from "express";
import { stripe } from "../services/stripe.service";
import { prisma } from "../db";

export const paymentsRouter = Router();

// Stripe richiede il body raw (non JSON parsato) per verificare la firma.
paymentsRouter.post("/stripe", raw({ type: "application/json" }), async (req, res) => {
  const signature = req.headers["stripe-signature"] as string;

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET || ""
    );
  } catch (err) {
    return res.status(400).send(`Firma webhook non valida: ${err}`);
  }

  if (event.type === "payment_intent.succeeded") {
    const intent = event.data.object as { metadata: { giftId?: string } };
    const giftId = intent.metadata.giftId;

    if (giftId) {
      await prisma.gift.update({
        where: { id: giftId },
        data: { stato: "notificato" },
      });
      // TODO: qui va agganciato il servizio di notifica (push/SMS)
      // che avvisa il destinatario tramite destinatarioTelefono.
    }
  }

  res.json({ received: true });
});
