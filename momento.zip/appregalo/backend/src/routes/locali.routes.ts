import { Router } from "express";
import { prisma } from "../db";

export const localiRouter = Router();

// GET /locali?citta=Roma&q=vino
localiRouter.get("/", async (req, res) => {
  const { citta, q } = req.query;

  const locali = await prisma.locale.findMany({
    where: {
      stato: "attivo",
      ...(citta ? { citta: String(citta) } : {}),
      ...(q ? { nome: { contains: String(q), mode: "insensitive" } } : {}),
    },
    orderBy: { nome: "asc" },
  });

  res.json(locali);
});

localiRouter.get("/:id", async (req, res) => {
  const locale = await prisma.locale.findUnique({
    where: { id: req.params.id },
  });

  if (!locale) return res.status(404).json({ errore: "Locale non trovato" });
  res.json(locale);
});

// GET /locali/:id/menu — voci attive, usate dalla schermata di scelta
// prodotto/quantità lato mobile.
localiRouter.get("/:id/menu", async (req, res) => {
  const vociMenu = await prisma.voceMenu.findMany({
    where: { localeId: req.params.id, attivo: true },
    orderBy: [{ categoria: "asc" }, { nome: "asc" }],
  });

  res.json(vociMenu);
});
