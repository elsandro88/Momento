# App regalo drink/cibo — scaffold iniziale

Struttura del progetto:

```
appregalo/
  backend/     API Node.js + TypeScript + Prisma (Postgres) + Stripe Connect
  mobile/      App Expo/React Native (mittente e destinatario)
  staff-web/   Pagina unica per il banco: scanner QR + riscossione + scontrino
  admin-web/   Pagina unica per l'amministrazione: locali e payout
```

## Modello di ricavo

Il locale non paga alcuna commissione: riceve sempre l'intero importo del regalo. Il ricavo della piattaforma è una commissione di servizio addebitata al mittente al momento del pagamento (visibile e separata, non nascosta nel totale) — percentuale + fissa, configurabile via `SERVIZIO_PERCENTUALE` e `SERVIZIO_FISSA` in `.env` (default 5% + 0,30 €). La logica è in `backend/src/utils/commissione.ts`.

## Backend

```bash
cd backend
cp .env.example .env   # inserisci DATABASE_URL, JWT_SECRET, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET
npm install
npm run prisma:migrate  # crea le tabelle su Postgres
EMAIL=tu@esempio.it PASSWORD=una-password-lunga npm run seed:admin  # crea il primo account admin
npm run dev
```

Endpoint di autenticazione:
- `POST /auth/utente/richiedi-otp` / `POST /auth/utente/verifica-otp` — accesso del mittente via SMS (in sviluppo il codice va solo in console, vedi sotto)
- `POST /auth/locale/accedi` — accesso staff con ID locale + PIN (il PIN viene generato e mostrato una sola volta alla creazione del locale, da `admin-web`)
- `POST /auth/admin/accedi` — accesso amministrazione con email + password

Endpoint principali (tutti tranne quelli sopra e `GET /gifts/:id` richiedono un token `Authorization: Bearer ...`):
- `GET /locali?citta=Roma&q=vino` — elenco locali convenzionati
- `GET /locali/:id/menu` — voci di menu del locale (nome, categoria, prezzo)
- `POST /gifts` — crea un regalo con una o più righe (`items`, ciascuna con quantità), calcola la commissione di servizio a carico del mittente e avvia il relativo payment intent Stripe (l'importo destinato al locale resta intero)
- `GET /gifts/:id` — dettaglio regalo con le righe incluse (usato dalla schermata del destinatario)
- `POST /redeem` — validazione codice lato locale (da collegare alla web app staff)
- `POST /webhooks/stripe` — conferma pagamento asincrona da Stripe

## Staff al banco (staff-web)

Un solo file HTML, nessuna build: si apre da un link o da un tablet dedicato al banco.

```bash
# basta servirlo come file statico, es.
npx serve staff-web
```

Alla prima apertura chiede l'ID del locale (in produzione arriverebbe da un login, qui è
una scorciatoia via `localStorage`). Poi:

1. Inquadra il QR mostrato dal destinatario nell'app mobile — o digita il codice a mano se la fotocamera non è disponibile.
2. Il codice viene validato e riscosso in un solo passaggio (niente doppia conferma: la velocità al banco conta più della cautela in più).
3. Compaiono le righe del regalo (prodotto × quantità) — pronte per essere lette a voce alla cassa o stampate come scontrino con il tasto dedicato (usa la stampa di sistema, compatibile con qualunque stampante da banco già collegata al computer/tablet).

- `GET /admin/locali` / `POST /admin/locali` / `PATCH /admin/locali/:id` — gestione locali (onboarding, approvazione, conto Stripe)
- `GET /admin/payouts/pending` — regali riscossi non ancora liquidati, raggruppati per locale — importo pieno, il locale non paga alcuna commissione
- `POST /admin/payouts/process` — crea i payout della settimana e avvia i trasferimenti Stripe Connect, sempre per l'importo pieno

## Amministrazione (admin-web)

Anche questa una pagina sola, senza build:

```bash
npx serve admin-web
```

Due sezioni: **locali** (elenco, creazione, approvazione/sospensione, commissione, conto Stripe) e **payout** (importi netti in sospeso per locale, con un tasto per elaborarli tutti insieme). Nessuna autenticazione, stesso discorso fatto per `staff-web` — da aggiungere prima di un vero utilizzo.

## Mobile

```bash
cd mobile
npm install
npx expo start
```

Le schermate coprono il flusso mittente → destinatario:
`Home` (scelta locale) → `LocaleDetail` (importo) → `SendGift` (messaggio e pagamento)
→ `Confirmation` (per il mittente) / `ReceiveGift` (per il destinatario, aperta da link/SMS).

## Cosa manca, volutamente, in questa prima versione

- Autenticazione utenti (login/registrazione) — da aggiungere prima di sostituire `MITTENTE_ID_DEMO`.
- Integrazione reale dello Stripe SDK lato mobile per confermare il `clientSecret` (`@stripe/stripe-react-native`, `useConfirmPayment`).
- Autenticazione ovunque: presente in tutte e tre le interfacce (OTP via SMS per l'app mobile, PIN per staff-web, email/password per admin-web) — ma l'invio SMS reale non è collegato (vedi punto sotto), e nessuna delle tre ha ancora un flusso di recupero (numero perso, PIN dimenticato, password dimenticata).
- Invio SMS reale: `POST /auth/utente/richiedi-otp` oggi stampa il codice in console invece di inviarlo — va collegato un provider (es. Twilio) prima che l'app sia usabile da qualcuno che non sia sviluppatore.
- Schedulazione dei payout: oggi `POST /admin/payouts/process` va lanciato a mano dall'admin-web — in produzione conviene un cron settimanale che lo chiama da solo.
- Job schedulato per generare i `Payout` settimanali aggregando i regali riscossi.
- Servizio di notifica push/SMS al destinatario (punto già segnato con TODO in `payments.routes.ts`).
- Popolamento del menu per locale (`VoceMenu`): oggi va inserito a mano/via seed, serve un'interfaccia (anche solo un form web) perché i locali lo gestiscano da soli.
- Stampa scontrino: usa la finestra di stampa di sistema, quindi il layout va verificato sulla stampante da banco reale — non è garantito che il formato termico stretto (58/80mm) sia già corretto.
