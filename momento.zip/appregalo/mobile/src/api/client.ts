import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { RigaCarrello } from "../types";

// In sviluppo punta al backend locale; in produzione va sostituito
// con l'URL reale del deploy (variabile d'ambiente Expo).
export const api = axios.create({
  baseURL: process.env.EXPO_PUBLIC_API_URL || "http://localhost:3000",
});

// Allega il token salvato a ogni richiesta, se presente — evita di
// doverlo passare a mano in ogni singola chiamata.
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem("appregalo:token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export async function richiediOtp(telefono: string) {
  await api.post("/auth/utente/richiedi-otp", { telefono });
}

export async function verificaOtp(telefono: string, codice: string) {
  const { data } = await api.post("/auth/utente/verifica-otp", { telefono, codice });
  return data as { token: string; utente: { id: string } };
}

export async function cercaLocali(citta: string, query?: string) {
  const { data } = await api.get("/locali", { params: { citta, q: query } });
  return data;
}

export async function ottieniMenu(localeId: string) {
  const { data } = await api.get(`/locali/${localeId}/menu`);
  return data;
}

export async function creaRegalo(payload: {
  destinatarioTelefono: string;
  localeId: string;
  messaggio?: string;
  items: RigaCarrello[];
}) {
  const { data } = await api.post("/gifts", payload);
  return data;
}

export async function ottieniRegalo(giftId: string) {
  const { data } = await api.get(`/gifts/${giftId}`);
  return data;
}
