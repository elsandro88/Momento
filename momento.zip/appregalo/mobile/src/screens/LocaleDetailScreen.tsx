import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, TextInput, ScrollView, StyleSheet } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../navigation/AppNavigator";
import { ottieniMenu } from "../api/client";
import { RigaCarrello, VoceMenu } from "../types";

type Props = NativeStackScreenProps<RootStackParamList, "LocaleDetail">;

export default function LocaleDetailScreen({ route, navigation }: Props) {
  const { locale } = route.params;
  const [menu, setMenu] = useState<VoceMenu[]>([]);
  const [quantita, setQuantita] = useState<Record<string, number>>({});
  const [importoLibero, setImportoLibero] = useState("");

  useEffect(() => {
    ottieniMenu(locale.id).then(setMenu).catch(() => setMenu([]));
  }, [locale.id]);

  const cambiaQuantita = (voceId: string, delta: number) => {
    setQuantita((prev) => {
      const attuale = prev[voceId] || 0;
      const nuova = Math.max(0, attuale + delta);
      return { ...prev, [voceId]: nuova };
    });
  };

  const righeCarrello: RigaCarrello[] = menu
    .filter((voce) => (quantita[voce.id] || 0) > 0)
    .map((voce) => ({
      voceMenuId: voce.id,
      nomeProdotto: voce.nome,
      quantita: quantita[voce.id],
      prezzoUnitario: voce.prezzo,
    }));

  const importoLiberoNumero = parseFloat(importoLibero.replace(",", ".")) || 0;
  if (importoLiberoNumero > 0) {
    righeCarrello.push({
      nomeProdotto: "Importo libero",
      quantita: 1,
      prezzoUnitario: importoLiberoNumero,
    });
  }

  const numeroArticoli = righeCarrello.reduce((tot, r) => tot + r.quantita, 0);
  const totale = righeCarrello.reduce((tot, r) => tot + r.quantita * r.prezzoUnitario, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.nome}>{locale.nome}</Text>
      <Text style={styles.sottotitolo}>{locale.citta}</Text>

      <ScrollView style={{ flex: 1 }}>
        {menu.map((voce) => (
          <View key={voce.id} style={styles.riga}>
            <View style={{ flex: 1 }}>
              <Text style={styles.voceNome}>{voce.nome}</Text>
              <Text style={styles.vocePrezzo}>{voce.prezzo.toFixed(2)} €</Text>
            </View>
            <View style={styles.stepper}>
              <TouchableOpacity style={styles.stepperBottone} onPress={() => cambiaQuantita(voce.id, -1)}>
                <Text style={styles.stepperSegno}>–</Text>
              </TouchableOpacity>
              <Text style={styles.stepperValore}>{quantita[voce.id] || 0}</Text>
              <TouchableOpacity style={styles.stepperBottone} onPress={() => cambiaQuantita(voce.id, 1)}>
                <Text style={styles.stepperSegno}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <View style={styles.riga}>
          <Text style={styles.voceNomeLibero}>Importo libero</Text>
          <TextInput
            style={styles.importoInput}
            placeholder="0,00 €"
            keyboardType="decimal-pad"
            value={importoLibero}
            onChangeText={setImportoLibero}
          />
        </View>
      </ScrollView>

      <View style={styles.riepilogo}>
        <Text style={styles.riepilogoTesto}>{numeroArticoli} articoli</Text>
        <Text style={styles.riepilogoTotale}>{totale.toFixed(2)} €</Text>
      </View>

      <TouchableOpacity
        style={[styles.bottone, righeCarrello.length === 0 && styles.bottoneDisabilitato]}
        disabled={righeCarrello.length === 0}
        onPress={() => navigation.navigate("SendGift", { locale, items: righeCarrello })}
      >
        <Text style={styles.bottoneTesto}>Continua</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  nome: { fontSize: 18, fontWeight: "600" },
  sottotitolo: { fontSize: 13, color: "#666", marginBottom: 16 },
  riga: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
    paddingVertical: 10,
  },
  voceNome: { fontSize: 14 },
  vocePrezzo: { fontSize: 12, color: "#888", marginTop: 2 },
  voceNomeLibero: { fontSize: 14, color: "#666" },
  stepper: { flexDirection: "row", alignItems: "center", gap: 10 },
  stepperBottone: {
    width: 26, height: 26, borderRadius: 13, borderWidth: 1, borderColor: "#ccc",
    alignItems: "center", justifyContent: "center",
  },
  stepperSegno: { fontSize: 15, color: "#333" },
  stepperValore: { fontSize: 14, minWidth: 16, textAlign: "center" },
  importoInput: { fontSize: 14, minWidth: 80, textAlign: "right" },
  riepilogo: {
    flexDirection: "row", justifyContent: "space-between",
    borderTopWidth: 1, borderTopColor: "#eee", paddingTop: 10, marginTop: 8,
  },
  riepilogoTesto: { color: "#666" },
  riepilogoTotale: { fontWeight: "600" },
  bottone: { backgroundColor: "#111", borderRadius: 10, padding: 14, alignItems: "center", marginTop: 12 },
  bottoneDisabilitato: { opacity: 0.4 },
  bottoneTesto: { color: "#fff", fontWeight: "600" },
});
