import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../navigation/AppNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "Confirmation">;

export default function ConfirmationScreen({ navigation }: Props) {
  return (
    <View style={styles.container}>
      <Text style={styles.titolo}>Regalo inviato</Text>
      <Text style={styles.sottotitolo}>
        Il tuo amico riceverà una notifica appena il pagamento sarà confermato.
      </Text>
      <TouchableOpacity
        style={styles.bottone}
        onPress={() => navigation.popToTop()}
      >
        <Text style={styles.bottoneTesto}>Torna alla home</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: "#fff", justifyContent: "center", alignItems: "center" },
  titolo: { fontSize: 20, fontWeight: "600", marginBottom: 8 },
  sottotitolo: { fontSize: 14, color: "#666", textAlign: "center", marginBottom: 32 },
  bottone: { backgroundColor: "#111", borderRadius: 10, padding: 14, paddingHorizontal: 24 },
  bottoneTesto: { color: "#fff", fontWeight: "600" },
});
