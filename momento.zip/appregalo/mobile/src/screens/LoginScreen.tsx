import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { richiediOtp, verificaOtp } from "../api/client";
import { useAuth } from "../auth/AuthContext";

export default function LoginScreen() {
  const { accedi } = useAuth();
  const [passo, setPasso] = useState<"telefono" | "codice">("telefono");
  const [telefono, setTelefono] = useState("");
  const [codice, setCodice] = useState("");
  const [caricamento, setCaricamento] = useState(false);

  const inviaOtp = async () => {
    if (telefono.length < 6) {
      Alert.alert("Numero non valido", "Controlla il numero di telefono inserito.");
      return;
    }
    setCaricamento(true);
    try {
      await richiediOtp(telefono);
      setPasso("codice");
    } catch {
      Alert.alert("Errore", "Non è stato possibile inviare il codice. Riprova.");
    } finally {
      setCaricamento(false);
    }
  };

  const confermaCodice = async () => {
    if (codice.length < 4) {
      Alert.alert("Codice incompleto", "Inserisci il codice a 4 cifre ricevuto via SMS.");
      return;
    }
    setCaricamento(true);
    try {
      const { token, utente } = await verificaOtp(telefono, codice);
      await accedi(token, utente.id);
    } catch {
      Alert.alert("Codice errato", "Il codice inserito non è valido o è scaduto.");
    } finally {
      setCaricamento(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titolo}>Bentornato</Text>
      <Text style={styles.sottotitolo}>
        {passo === "telefono"
          ? "Inserisci il tuo numero per accedere"
          : `Abbiamo inviato un codice a ${telefono}`}
      </Text>

      {passo === "telefono" ? (
        <>
          <TextInput
            style={styles.input}
            placeholder="Numero di telefono"
            keyboardType="phone-pad"
            value={telefono}
            onChangeText={setTelefono}
            autoFocus
          />
          <TouchableOpacity style={styles.bottone} onPress={inviaOtp} disabled={caricamento}>
            <Text style={styles.bottoneTesto}>{caricamento ? "Invio..." : "Invia codice"}</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <TextInput
            style={[styles.input, styles.inputCodice]}
            placeholder="0000"
            keyboardType="number-pad"
            maxLength={4}
            value={codice}
            onChangeText={setCodice}
            autoFocus
          />
          <TouchableOpacity style={styles.bottone} onPress={confermaCodice} disabled={caricamento}>
            <Text style={styles.bottoneTesto}>{caricamento ? "Verifica..." : "Conferma"}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setPasso("telefono")}>
            <Text style={styles.link}>Cambia numero</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: "#fff", justifyContent: "center" },
  titolo: { fontSize: 22, fontWeight: "600", marginBottom: 6 },
  sottotitolo: { fontSize: 14, color: "#666", marginBottom: 24 },
  input: { borderWidth: 1, borderColor: "#ddd", borderRadius: 10, padding: 14, fontSize: 15 },
  inputCodice: { textAlign: "center", fontSize: 24, letterSpacing: 8 },
  bottone: { backgroundColor: "#111", borderRadius: 10, padding: 14, alignItems: "center", marginTop: 16 },
  bottoneTesto: { color: "#fff", fontWeight: "600" },
  link: { textAlign: "center", color: "#666", marginTop: 16, fontSize: 13 },
});
