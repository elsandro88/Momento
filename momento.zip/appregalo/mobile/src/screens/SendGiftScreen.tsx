import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../navigation/AppNavigator";
import { creaRegalo } from "../api/client";

// Stessa formula usata lato backend (src/utils/commissione.ts) — qui
// serve solo per mostrare un'anteprima trasparente prima del
// pagamento; il valore autoritativo resta quello calcolato dal server.
const SERVIZIO_PERCENTUALE = 5;
const SERVIZIO_FISSA = 0.3;

function calcolaFeeServizio(importoTotale: number): number {
  return Math.round((importoTotale * (SERVIZIO_PERCENTUALE / 100) + SERVIZIO_FISSA) * 100) / 100;
}

type Props = NativeStackScreenProps<RootStackParamList, "SendGift">;

export default function SendGiftScreen({ route, navigation }: Props) {
  const { locale, items } = route.params;
  const [telefono, setTelefono] = useState("");
  const [messaggio, setMessaggio] = useState("");
  const [inviando, setInviando] = useState(false);

  const totale = items.reduce((tot, r) => tot + r.quantita * r.prezzoUnitario, 0);
  const feeServizio = calcolaFeeServizio(totale);
  const totaleAddebitato = totale + feeServizio;

  const invia = async () => {
    if (!telefono) {
      Alert.alert("Manca il destinatario", "Inserisci il numero di telefono dell'amico.");
      return;
    }
    setInviando(true);
    try {
      const { gift } = await creaRegalo({
        destinatarioTelefono: telefono,
        localeId: locale.id,
        messaggio,
        items,
      });
      // Qui andrebbe confermato il clientSecret con lo Stripe SDK
      // (useConfirmPayment di @stripe/stripe-react-native) prima di
      // considerare il pagamento riuscito.
      navigation.replace("Confirmation", { giftId: gift.id });
    } catch (e) {
      Alert.alert("Errore", "Non è stato possibile inviare il regalo. Riprova.");
    } finally {
      setInviando(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>A</Text>
      <TextInput
        style={styles.input}
        placeholder="Numero di telefono"
        keyboardType="phone-pad"
        value={telefono}
        onChangeText={setTelefono}
      />

      <Text style={styles.label}>Cosa stai regalando</Text>
      <View style={styles.riepilogoBox}>
        {items.map((r, i) => (
          <View key={i} style={styles.riepilogoRiga}>
            <Text style={styles.riepilogoVoce}>{r.quantita}× {r.nomeProdotto}</Text>
            <Text style={styles.riepilogoPrezzo}>{(r.quantita * r.prezzoUnitario).toFixed(2)} €</Text>
          </View>
        ))}
      </View>

      <Text style={styles.label}>Messaggio</Text>
      <TextInput
        style={[styles.input, styles.messaggio]}
        placeholder="Un pensiero per il tuo amico..."
        multiline
        value={messaggio}
        onChangeText={setMessaggio}
      />

      <View style={styles.totaleRiga}>
        <Text style={styles.totaleLabel}>Regalo</Text>
        <Text style={styles.totaleValoreSecondario}>{totale.toFixed(2)} €</Text>
      </View>
      <View style={styles.totaleRigaSecondaria}>
        <Text style={styles.totaleLabel}>Commissione di servizio</Text>
        <Text style={styles.totaleValoreSecondario}>{feeServizio.toFixed(2)} €</Text>
      </View>
      <View style={styles.totaleRigaSecondaria}>
        <Text style={[styles.totaleLabel, { fontWeight: "600" }]}>Totale addebitato</Text>
        <Text style={styles.totaleValore}>{totaleAddebitato.toFixed(2)} €</Text>
      </View>

      <TouchableOpacity style={styles.bottone} onPress={invia} disabled={inviando}>
        <Text style={styles.bottoneTesto}>{inviando ? "Invio in corso..." : "Invia regalo"}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  label: { fontSize: 12, color: "#666", marginBottom: 6, marginTop: 12 },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 12,
    fontSize: 14,
  },
  messaggio: { minHeight: 80, textAlignVertical: "top" },
  riepilogoBox: {
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 10,
    padding: 12,
  },
  riepilogoRiga: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 4 },
  riepilogoVoce: { fontSize: 13 },
  riepilogoPrezzo: { fontSize: 13, color: "#666" },
  totaleRiga: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderTopWidth: 1,
    borderTopColor: "#eee",
    paddingTop: 12,
    marginTop: 24,
  },
  totaleRigaSecondaria: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 6,
  },
  totaleValoreSecondario: { color: "#666", fontSize: 13 },
  totaleLabel: { color: "#666" },
  totaleValore: { fontWeight: "600" },
  bottone: {
    backgroundColor: "#111",
    borderRadius: 10,
    padding: 14,
    alignItems: "center",
    marginTop: 20,
  },
  bottoneTesto: { color: "#fff", fontWeight: "600" },
});
