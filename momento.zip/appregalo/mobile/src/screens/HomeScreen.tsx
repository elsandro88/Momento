import React, { useEffect, useState } from "react";
import { View, TextInput, FlatList, Text, TouchableOpacity, StyleSheet } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../navigation/AppNavigator";
import { cercaLocali } from "../api/client";
import { Locale } from "../types";

type Props = NativeStackScreenProps<RootStackParamList, "Home">;

export default function HomeScreen({ navigation }: Props) {
  const [query, setQuery] = useState("");
  const [locali, setLocali] = useState<Locale[]>([]);

  useEffect(() => {
    // Città fissa "Roma" per l'MVP: il selettore città arriva dopo
    // aver validato il modello in una sola area.
    cercaLocali("Roma", query).then(setLocali).catch(() => setLocali([]));
  }, [query]);

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.search}
        placeholder="Cerca locale o città"
        value={query}
        onChangeText={setQuery}
      />
      <FlatList
        data={locali}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("LocaleDetail", { locale: item })}
          >
            <Text style={styles.nome}>{item.nome}</Text>
            <Text style={styles.sottotitolo}>{item.citta} · {item.categoria}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.vuoto}>Nessun locale trovato</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  search: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
  },
  card: {
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  nome: { fontSize: 15, fontWeight: "600" },
  sottotitolo: { fontSize: 13, color: "#666", marginTop: 2 },
  vuoto: { textAlign: "center", color: "#999", marginTop: 40 },
});
