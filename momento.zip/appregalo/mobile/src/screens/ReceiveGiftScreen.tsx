import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, ActivityIndicator } from "react-native";
import QRCode from "react-native-qrcode-svg";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../navigation/AppNavigator";
import { ottieniRegalo } from "../api/client";
import { Gift } from "../types";

type Props = NativeStackScreenProps<RootStackParamList, "ReceiveGift">;

// Questa schermata si apre dal link/SMS che il destinatario riceve,
// non serve navigazione precedente nello stack.
export default function ReceiveGiftScreen({ route }: Props) {
  const { giftId } = route.params;
  const [gift, setGift] = useState<Gift | null>(null);

  useEffect(() => {
    ottieniRegalo(giftId).then(setGift).catch(() => setGift(null));
  }, [giftId]);

  if (!gift) {
    return (
      <View style={styles.centrato}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titolo}>Hai ricevuto un regalo!</Text>
      <Text style={styles.dettaglio}>da {gift.locale.nome}</Text>

      <View style={styles.righeBox}>
        {gift.items.map((item) => (
          <Text key={item.id} style={styles.riga}>
            {item.quantita}× {item.nomeProdotto}
          </Text>
        ))}
      </View>

      {gift.messaggio ? <Text style={styles.messaggio}>"{gift.messaggio}"</Text> : null}

      <View style={styles.codiceBox}>
        <QRCode value={gift.codice} size={130} color="#111" backgroundColor="#fff" />
      </View>
      <Text style={styles.codiceTesto}>{gift.codice}</Text>
      <Text style={styles.istruzioni}>Fai inquadrare il QR al banco, o mostra il codice</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: "#fff", alignItems: "center", justifyContent: "center" },
  centrato: { flex: 1, alignItems: "center", justifyContent: "center" },
  titolo: { fontSize: 18, fontWeight: "600", marginBottom: 8 },
  dettaglio: { fontSize: 14, color: "#666", textAlign: "center", marginBottom: 12 },
  righeBox: { marginBottom: 16, alignItems: "center" },
  riga: { fontSize: 14, marginBottom: 2 },
  messaggio: { fontSize: 13, fontStyle: "italic", color: "#888", textAlign: "center", marginBottom: 24 },
  codiceBox: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
  },
  codiceTesto: { fontSize: 16, fontWeight: "600", letterSpacing: 2, marginBottom: 8 },
  istruzioni: { fontSize: 12, color: "#999" },
});
