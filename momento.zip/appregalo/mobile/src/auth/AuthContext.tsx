import React, { createContext, useContext, useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

type AuthContextValue = {
  token: string | null;
  utenteId: string | null;
  caricamentoIniziale: boolean;
  accedi: (token: string, utenteId: string) => Promise<void>;
  esci: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

const CHIAVE_TOKEN = "appregalo:token";
const CHIAVE_UTENTE = "appregalo:utenteId";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [utenteId, setUtenteId] = useState<string | null>(null);
  const [caricamentoIniziale, setCaricamentoIniziale] = useState(true);

  useEffect(() => {
    // Ripristina la sessione salvata, così l'utente non deve rifare
    // l'OTP a ogni riapertura dell'app.
    Promise.all([
      AsyncStorage.getItem(CHIAVE_TOKEN),
      AsyncStorage.getItem(CHIAVE_UTENTE),
    ]).then(([tokenSalvato, idSalvato]) => {
      if (tokenSalvato && idSalvato) {
        setToken(tokenSalvato);
        setUtenteId(idSalvato);
      }
      setCaricamentoIniziale(false);
    });
  }, []);

  const accedi = async (nuovoToken: string, nuovoUtenteId: string) => {
    await AsyncStorage.setItem(CHIAVE_TOKEN, nuovoToken);
    await AsyncStorage.setItem(CHIAVE_UTENTE, nuovoUtenteId);
    setToken(nuovoToken);
    setUtenteId(nuovoUtenteId);
  };

  const esci = async () => {
    await AsyncStorage.multiRemove([CHIAVE_TOKEN, CHIAVE_UTENTE]);
    setToken(null);
    setUtenteId(null);
  };

  return (
    <AuthContext.Provider value={{ token, utenteId, caricamentoIniziale, accedi, esci }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const contesto = useContext(AuthContext);
  if (!contesto) throw new Error("useAuth va usato dentro AuthProvider");
  return contesto;
}
