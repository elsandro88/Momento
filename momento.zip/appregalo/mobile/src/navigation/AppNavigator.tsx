import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Locale, RigaCarrello } from "../types";

import HomeScreen from "../screens/HomeScreen";
import LocaleDetailScreen from "../screens/LocaleDetailScreen";
import SendGiftScreen from "../screens/SendGiftScreen";
import ConfirmationScreen from "../screens/ConfirmationScreen";
import ReceiveGiftScreen from "../screens/ReceiveGiftScreen";
import LoginScreen from "../screens/LoginScreen";

export type RootStackParamList = {
  Login: undefined;
  Home: undefined;
  LocaleDetail: { locale: Locale };
  SendGift: { locale: Locale; items: RigaCarrello[] };
  Confirmation: { giftId: string };
  ReceiveGift: { giftId: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

// ReceiveGift resta raggiungibile anche senza login: il destinatario
// apre questo link da un SMS prima ancora di avere un account (vedi
// GET /gifts/:id lato backend, volutamente pubblico).
const linking = {
  prefixes: ["appregalo://", "https://appregalo.it"],
  config: {
    screens: {
      ReceiveGift: "regalo/:giftId",
      Login: "accedi",
      Home: "home",
    },
  },
};

export default function AppNavigator({ autenticato }: { autenticato: boolean }) {
  return (
    <NavigationContainer linking={linking}>
      <Stack.Navigator
        screenOptions={{ headerTitleAlign: "center" }}
        initialRouteName={autenticato ? "Home" : "Login"}
      >
        {!autenticato && (
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        )}

        {autenticato && (
          <>
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: "Scegli il locale" }} />
            <Stack.Screen name="LocaleDetail" component={LocaleDetailScreen} options={{ title: "Cosa offri" }} />
            <Stack.Screen name="SendGift" component={SendGiftScreen} options={{ title: "Invia il regalo" }} />
            <Stack.Screen
              name="Confirmation"
              component={ConfirmationScreen}
              options={{ title: "Fatto", headerBackVisible: false }}
            />
          </>
        )}

        <Stack.Screen name="ReceiveGift" component={ReceiveGiftScreen} options={{ title: "Il tuo regalo" }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
