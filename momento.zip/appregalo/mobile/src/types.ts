export type Locale = {
  id: string;
  nome: string;
  citta: string;
  categoria: string;
};

export type VoceMenu = {
  id: string;
  nome: string;
  categoria: "da_bere" | "da_mangiare";
  prezzo: number;
};

// Una riga scelta dal mittente: voceMenuId assente = "importo libero".
export type RigaCarrello = {
  voceMenuId?: string;
  nomeProdotto: string;
  quantita: number;
  prezzoUnitario: number;
};

export type GiftItem = {
  id: string;
  nomeProdotto: string;
  quantita: number;
  prezzoUnitario: string;
};

export type Gift = {
  id: string;
  codice: string;
  importoTotale: string;
  messaggio?: string;
  stato: "in_attesa" | "notificato" | "riscosso" | "scaduto" | "rimborsato";
  locale: Locale;
  items: GiftItem[];
};
