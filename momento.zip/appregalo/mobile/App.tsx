import React from "react";
import { View, ActivityIndicator } from "react-native";
import { AuthProvider, useAuth } from "./src/auth/AuthContext";
import AppNavigator from "./src/navigation/AppNavigator";

function Radice() {
  const { token, caricamentoIniziale } = useAuth();

  if (caricamentoIniziale) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator />
      </View>
    );
  }

  // ReceiveGift resta registrata nel navigatore anche quando non
  // autenticato (vedi AppNavigator): così un link ricevuto via SMS
  // funziona subito, senza dover passare da un login forzato.
  return <AppNavigator autenticato={!!token} />;
}

export default function App() {
  return (
    <AuthProvider>
      <Radice />
    </AuthProvider>
  );
}
